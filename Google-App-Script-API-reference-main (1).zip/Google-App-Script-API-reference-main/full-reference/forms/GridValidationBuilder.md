## [GridValidationBuilder](https://developers.google.com/apps-script/reference/forms/grid-validation-builder)

### Methods

|                                                                           Method                                                                           |                                                Return type                                                 |                     Brief description                      |
|------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------|------------------------------------------------------------|
| [requireLimitOneResponsePerColumn()](https://developers.google.com/apps-script/reference/forms/grid-validation-builder#requireLimitOneResponsePerColumn()) | [GridValidationBuilder](https://developers.google.com/apps-script/reference/forms/grid-validation-builder) | Requires limit of one response per column for a grid item. |
