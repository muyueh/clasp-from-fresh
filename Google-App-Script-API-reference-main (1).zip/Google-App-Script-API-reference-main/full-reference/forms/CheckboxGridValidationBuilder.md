## [CheckboxGridValidationBuilder](https://developers.google.com/apps-script/reference/forms/checkbox-grid-validation-builder)

### Methods

|                                                                               Method                                                                                |                                                         Return type                                                         |                     Brief description                      |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------|
| [requireLimitOneResponsePerColumn()](https://developers.google.com/apps-script/reference/forms/checkbox-grid-validation-builder#requireLimitOneResponsePerColumn()) | [CheckboxGridValidationBuilder](https://developers.google.com/apps-script/reference/forms/checkbox-grid-validation-builder) | Requires limit of one response per column for a grid item. |
