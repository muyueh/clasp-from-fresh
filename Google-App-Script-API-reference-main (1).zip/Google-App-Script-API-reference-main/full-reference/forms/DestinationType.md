## [DestinationType](https://developers.google.com/apps-script/reference/forms/destination-type)

### Properties

|   Property    |  Type  |                           Description                            |
|---------------|--------|------------------------------------------------------------------|
| `SPREADSHEET` | `Enum` | A Google Sheets spreadsheet as a destination for form responses. |
