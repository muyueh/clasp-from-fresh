## [CheckboxValidation](https://developers.google.com/apps-script/reference/forms/checkbox-validation)
