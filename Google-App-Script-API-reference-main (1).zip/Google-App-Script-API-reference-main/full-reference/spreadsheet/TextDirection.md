## [TextDirection](https://developers.google.com/apps-script/reference/spreadsheet/text-direction)

### Properties

|    Property     |  Type  |          Description          |
|-----------------|--------|-------------------------------|
| `LEFT_TO_RIGHT` | `Enum` | Left-to-right text direction. |
| `RIGHT_TO_LEFT` | `Enum` | Right-to-left text direction. |
