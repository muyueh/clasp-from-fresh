## [DateTimeGroupingRule](https://developers.google.com/apps-script/reference/spreadsheet/date-time-grouping-rule)

### Methods

|                                                         Method                                                         |                                                       Return type                                                        |               Brief description               |
|------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------|
| [getRuleType()](https://developers.google.com/apps-script/reference/spreadsheet/date-time-grouping-rule#getRuleType()) | [DateTimeGroupingRuleType](https://developers.google.com/apps-script/reference/spreadsheet/date-time-grouping-rule-type) | Gets the type of the date-time grouping rule. |
