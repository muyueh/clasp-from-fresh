## [ProtectionType](https://developers.google.com/apps-script/reference/spreadsheet/protection-type)

### Properties

| Property |  Type  |       Description       |
|----------|--------|-------------------------|
| `RANGE`  | `Enum` | Protection for a range. |
| `SHEET`  | `Enum` | Protection for a sheet. |
