## [TabType](https://developers.google.com/apps-script/reference/document/tab-type)

### Properties

|    Property    |  Type  |                                                     Description                                                     |
|----------------|--------|---------------------------------------------------------------------------------------------------------------------|
| `DOCUMENT_TAB` | `Enum` | The type corresponding to [DocumentTab](https://developers.google.com/apps-script/reference/document/document-tab). |
