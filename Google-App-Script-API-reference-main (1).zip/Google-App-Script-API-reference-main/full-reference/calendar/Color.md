## [Color](https://developers.google.com/apps-script/reference/calendar/color)

### Properties

|   Property   |  Type  |       Description       |
|--------------|--------|-------------------------|
| `BLUE`       | `Enum` | Blue (`#2952A3`).       |
| `BROWN`      | `Enum` | Brown (`#8D6F47`).      |
| `CHARCOAL`   | `Enum` | Charcoal (`#4E5D6C`).   |
| `CHESTNUT`   | `Enum` | Chestnut (`#865A5A`).   |
| `GRAY`       | `Enum` | Gray (`#5A6986`).       |
| `GREEN`      | `Enum` | Green (`#0D7813`).      |
| `INDIGO`     | `Enum` | Indigo (`#5229A3`).     |
| `LIME`       | `Enum` | Lime (`#528800`).       |
| `MUSTARD`    | `Enum` | Mustard (`#88880E`).    |
| `OLIVE`      | `Enum` | Olive (`#6E6E41`).      |
| `ORANGE`     | `Enum` | Orange (`#BE6D00`).     |
| `PINK`       | `Enum` | Pink (`#B1365F`).       |
| `PLUM`       | `Enum` | Plum (`#705770`).       |
| `PURPLE`     | `Enum` | Purple (`#7A367A`).     |
| `RED`        | `Enum` | Red (`#A32929`).        |
| `RED_ORANGE` | `Enum` | Red-Orange (`#B1440E`). |
| `SEA_BLUE`   | `Enum` | Sea Blue (`#29527A`).   |
| `SLATE`      | `Enum` | Slate (`#4A716C`).      |
| `TEAL`       | `Enum` | Teal (`#28754E`).       |
| `TURQOISE`   | `Enum` | Turquoise (`#1B887A`).  |
| `YELLOW`     | `Enum` | Yellow (`#AB8B00`).     |
