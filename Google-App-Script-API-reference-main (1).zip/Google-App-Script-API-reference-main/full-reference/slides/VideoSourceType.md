## [VideoSourceType](https://developers.google.com/apps-script/reference/slides/video-source-type)

### Properties

|   Property    |  Type  |                Description                 |
|---------------|--------|--------------------------------------------|
| `UNSUPPORTED` | `Enum` | A video source type that is not supported. |
| `YOUTUBE`     | `Enum` | YouTube video.                             |
