## [PageRange](https://developers.google.com/apps-script/reference/slides/page-range)

### Methods

|                                             Method                                             |                                Return type                                |                                           Brief description                                            |
|------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------|
| [getPages()](https://developers.google.com/apps-script/reference/slides/page-range#getPages()) | [Page[]](https://developers.google.com/apps-script/reference/slides/page) | Returns the list of [Page](https://developers.google.com/apps-script/reference/slides/page) instances. |
