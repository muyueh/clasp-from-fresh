## [AutoTextType](https://developers.google.com/apps-script/reference/slides/auto-text-type)

### Properties

|    Property    |  Type  |               Description                |
|----------------|--------|------------------------------------------|
| `UNSUPPORTED`  | `Enum` | An auto text type that is not supported. |
| `SLIDE_NUMBER` | `Enum` | A slide number.                          |
