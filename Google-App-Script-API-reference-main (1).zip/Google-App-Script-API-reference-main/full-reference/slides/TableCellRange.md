## [TableCellRange](https://developers.google.com/apps-script/reference/slides/table-cell-range)

### Methods

|                                                     Method                                                     |                                     Return type                                      |                                                 Brief description                                                 |
|----------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------|
| [getTableCells()](https://developers.google.com/apps-script/reference/slides/table-cell-range#getTableCells()) | [TableCell[]](https://developers.google.com/apps-script/reference/slides/table-cell) | Returns the list of [TableCell](https://developers.google.com/apps-script/reference/slides/table-cell) instances. |
