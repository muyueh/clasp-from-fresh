## [AlignmentPosition](https://developers.google.com/apps-script/reference/slides/alignment-position)

### Properties

|      Property       |  Type  |           Description           |
|---------------------|--------|---------------------------------|
| `CENTER`            | `Enum` | Align to the center.            |
| `HORIZONTAL_CENTER` | `Enum` | Align to the horizontal center. |
| `VERTICAL_CENTER`   | `Enum` | Align to the vertical center.   |
