## [PageElementRange](https://developers.google.com/apps-script/reference/slides/page-element-range)

### Methods

|                                                        Method                                                        |                                       Return type                                        |                                                   Brief description                                                   |
|----------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------|
| [getPageElements()](https://developers.google.com/apps-script/reference/slides/page-element-range#getPageElements()) | [PageElement[]](https://developers.google.com/apps-script/reference/slides/page-element) | Returns the list of [PageElement](https://developers.google.com/apps-script/reference/slides/page-element) instances. |
