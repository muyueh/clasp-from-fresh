## CheckboxValidationBuilder

### Methods

- requireSelectAtLeast(number) — CheckboxValidationBuilder
- requireSelectAtMost(number) — CheckboxValidationBuilder
- requireSelectExactly(number) — CheckboxValidationBuilder
