## Item

### Methods

- asCheckboxGridItem() — CheckboxGridItem
- asCheckboxItem() — CheckboxItem
- asDateItem() — DateItem
- asDateTimeItem() — DateTimeItem
- asDurationItem() — DurationItem
- asGridItem() — GridItem
- asImageItem() — ImageItem
- asListItem() — ListItem
- asMultipleChoiceItem() — MultipleChoiceItem
- asPageBreakItem() — PageBreakItem
- asParagraphTextItem() — ParagraphTextItem
- asRatingItem() — RatingItem
- asScaleItem() — ScaleItem
- asSectionHeaderItem() — SectionHeaderItem
- asTextItem() — TextItem
- asTimeItem() — TimeItem
- asVideoItem() — VideoItem
- duplicate() — Item
- getHelpText() — String
- getId() — Integer
- getIndex() — Integer
- getTitle() — String
- getType() — ItemType
- setHelpText(text) — Item
- setTitle(title) — Item
