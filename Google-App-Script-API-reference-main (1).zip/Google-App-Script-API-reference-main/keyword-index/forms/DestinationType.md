## DestinationType

### Properties

- SPREADSHEET — Enum
