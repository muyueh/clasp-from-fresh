## FormResponse

### Methods

- getEditResponseUrl() — String
- getGradableItemResponses() — ItemResponse[]
- getGradableResponseForItem(item) — ItemResponse
- getId() — String
- getItemResponses() — ItemResponse[]
- getRespondentEmail() — String
- getResponseForItem(item) — ItemResponse
- getTimestamp() — Date
- submit() — FormResponse
- toPrefilledUrl() — String
- withItemGrade(gradedResponse) — FormResponse
- withItemResponse(response) — FormResponse
