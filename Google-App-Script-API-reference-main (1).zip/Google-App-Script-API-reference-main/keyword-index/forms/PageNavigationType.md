## PageNavigationType

### Properties

- CONTINUE — Enum
- GO_TO_PAGE — Enum
- RESTART — Enum
- SUBMIT — Enum
