## CheckboxGridValidationBuilder

### Methods

- requireLimitOneResponsePerColumn() — CheckboxGridValidationBuilder
