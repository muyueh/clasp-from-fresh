## VideoItem

### Methods

- duplicate() — VideoItem
- getAlignment() — Alignment
- getHelpText() — String
- getId() — Integer
- getIndex() — Integer
- getTitle() — String
- getType() — ItemType
- getWidth() — Integer
- setAlignment(alignment) — VideoItem
- setHelpText(text) — VideoItem
- setTitle(title) — VideoItem
- setVideoUrl(youtubeUrl) — VideoItem
- setWidth(width) — VideoItem
