## GridValidationBuilder

### Methods

- requireLimitOneResponsePerColumn() — GridValidationBuilder
