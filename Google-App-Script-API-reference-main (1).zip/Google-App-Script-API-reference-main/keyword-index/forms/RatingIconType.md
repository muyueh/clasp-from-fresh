## RatingIconType

### Properties

- STAR — Enum
- HEART — Enum
- THUMB_UP — Enum
