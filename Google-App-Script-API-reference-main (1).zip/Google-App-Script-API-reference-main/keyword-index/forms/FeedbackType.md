## FeedbackType

### Properties

- CORRECT — Enum
- INCORRECT — Enum
- GENERAL — Enum
