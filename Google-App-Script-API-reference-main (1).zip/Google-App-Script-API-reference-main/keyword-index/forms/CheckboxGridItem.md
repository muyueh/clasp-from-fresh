## CheckboxGridItem

### Methods

- clearValidation() — CheckboxGridItem
- createResponse(responses) — ItemResponse
- duplicate() — CheckboxGridItem
- getColumns() — String[]
- getHelpText() — String
- getId() — Integer
- getIndex() — Integer
- getRows() — String[]
- getTitle() — String
- getType() — ItemType
- isRequired() — Boolean
- setColumns(columns) — CheckboxGridItem
- setHelpText(text) — CheckboxGridItem
- setRequired(enabled) — CheckboxGridItem
- setRows(rows) — CheckboxGridItem
- setTitle(title) — CheckboxGridItem
- setValidation(validation) — CheckboxGridItem
