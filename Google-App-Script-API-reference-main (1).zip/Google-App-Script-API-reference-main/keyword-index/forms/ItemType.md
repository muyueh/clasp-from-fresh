## ItemType

### Properties

- CHECKBOX — Enum
- CHECKBOX_GRID — Enum
- DATE — Enum
- DATETIME — Enum
- DURATION — Enum
- GRID — Enum
- IMAGE — Enum
- LIST — Enum
- MULTIPLE_CHOICE — Enum
- PAGE_BREAK — Enum
- PARAGRAPH_TEXT — Enum
- RATING — Enum
- SCALE — Enum
- SECTION_HEADER — Enum
- TEXT — Enum
- TIME — Enum
- VIDEO — Enum
- FILE_UPLOAD — Enum
- UNSUPPORTED — Enum
