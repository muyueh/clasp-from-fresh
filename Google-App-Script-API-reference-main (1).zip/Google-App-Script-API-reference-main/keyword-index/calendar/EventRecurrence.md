## EventRecurrence

### Methods

- addDailyExclusion() — RecurrenceRule
- addDailyRule() — RecurrenceRule
- addDate(date) — EventRecurrence
- addDateExclusion(date) — EventRecurrence
- addMonthlyExclusion() — RecurrenceRule
- addMonthlyRule() — RecurrenceRule
- addWeeklyExclusion() — RecurrenceRule
- addWeeklyRule() — RecurrenceRule
- addYearlyExclusion() — RecurrenceRule
- addYearlyRule() — RecurrenceRule
- setTimeZone(timeZone) — EventRecurrence
