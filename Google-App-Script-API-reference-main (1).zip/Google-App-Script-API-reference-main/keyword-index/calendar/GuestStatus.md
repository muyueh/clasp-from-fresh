## GuestStatus

### Properties

- INVITED — Enum
- MAYBE — Enum
- NO — Enum
- OWNER — Enum
- YES — Enum
