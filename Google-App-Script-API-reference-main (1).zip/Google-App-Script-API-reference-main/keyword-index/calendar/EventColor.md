## EventColor

### Properties

- PALE_BLUE — Enum
- PALE_GREEN — Enum
- MAUVE — Enum
- PALE_RED — Enum
- YELLOW — Enum
- ORANGE — Enum
- CYAN — Enum
- GRAY — Enum
- BLUE — Enum
- GREEN — Enum
- RED — Enum
