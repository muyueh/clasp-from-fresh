## EventGuest

### Methods

- getAdditionalGuests() — Integer
- getEmail() — String
- getGuestStatus() — GuestStatus
- getName() — String
