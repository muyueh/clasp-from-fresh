## User

### Methods

- getDomain() — String
- getEmail() — String
- getName() — String
- getPhotoUrl() — String
