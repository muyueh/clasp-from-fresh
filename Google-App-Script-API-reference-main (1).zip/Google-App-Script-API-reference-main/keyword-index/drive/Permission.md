## Permission

### Properties

- VIEW — Enum
- EDIT — Enum
- COMMENT — Enum
- OWNER — Enum
- ORGANIZER — Enum
- FILE_ORGANIZER — Enum
- NONE — Enum
