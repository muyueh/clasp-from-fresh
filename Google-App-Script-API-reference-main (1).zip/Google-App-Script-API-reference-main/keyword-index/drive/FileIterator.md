## FileIterator

### Methods

- getContinuationToken() — String
- hasNext() — Boolean
- next() — File
