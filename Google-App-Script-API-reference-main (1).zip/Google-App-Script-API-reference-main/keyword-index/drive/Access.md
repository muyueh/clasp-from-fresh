## Access

### Properties

- ANYONE — Enum
- ANYONE_WITH_LINK — Enum
- DOMAIN — Enum
- DOMAIN_WITH_LINK — Enum
- PRIVATE — Enum
