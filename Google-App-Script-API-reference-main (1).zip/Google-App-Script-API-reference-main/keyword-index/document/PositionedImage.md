## PositionedImage

### Methods

- getAs(contentType) — Blob
- getBlob() — Blob
- getHeight() — Integer
- getId() — String
- getLayout() — PositionedLayout
- getLeftOffset() — Number
- getParagraph() — Paragraph
- getTopOffset() — Number
- getWidth() — Integer
- setHeight(height) — PositionedImage
- setLayout(layout) — PositionedImage
- setLeftOffset(offset) — PositionedImage
- setTopOffset(offset) — PositionedImage
- setWidth(width) — PositionedImage
