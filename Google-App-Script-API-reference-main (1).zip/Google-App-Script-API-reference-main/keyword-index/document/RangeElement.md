## RangeElement

### Methods

- getElement() — Element
- getEndOffsetInclusive() — Integer
- getStartOffset() — Integer
- isPartial() — Boolean
