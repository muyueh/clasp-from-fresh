## TabType

### Properties

- DOCUMENT_TAB — Enum
