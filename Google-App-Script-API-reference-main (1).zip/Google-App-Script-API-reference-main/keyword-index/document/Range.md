## Range

### Methods

- getRangeElements() — RangeElement[]
