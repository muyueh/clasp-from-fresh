## VerticalAlignment

### Properties

- BOTTOM — Enum
- CENTER — Enum
- TOP — Enum
