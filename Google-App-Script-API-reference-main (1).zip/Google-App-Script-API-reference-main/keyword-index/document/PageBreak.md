## PageBreak

### Methods

- copy() — PageBreak
- getAttributes() — Object
- getNextSibling() — Element
- getParent() — ContainerElement
- getPreviousSibling() — Element
- getType() — ElementType
- isAtDocumentEnd() — Boolean
- removeFromParent() — PageBreak
- setAttributes(attributes) — PageBreak
