## HorizontalRule

### Methods

- copy() — HorizontalRule
- getAttributes() — Object
- getNextSibling() — Element
- getParent() — ContainerElement
- getPreviousSibling() — Element
- getType() — ElementType
- isAtDocumentEnd() — Boolean
- removeFromParent() — HorizontalRule
- setAttributes(attributes) — HorizontalRule
