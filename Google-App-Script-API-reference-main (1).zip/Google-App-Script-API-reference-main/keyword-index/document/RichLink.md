## RichLink

### Methods

- copy() — RichLink
- getAttributes() — Object
- getMimeType() — String
- getNextSibling() — Element
- getParent() — ContainerElement
- getPreviousSibling() — Element
- getTitle() — String
- getType() — ElementType
- getUrl() — String
- isAtDocumentEnd() — Boolean
- merge() — RichLink
- removeFromParent() — RichLink
- setAttributes(attributes) — RichLink
