## NamedRange

### Methods

- getId() — String
- getName() — String
- getRange() — Range
- remove() — void
