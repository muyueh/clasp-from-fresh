## HorizontalAlignment

### Properties

- LEFT — Enum
- CENTER — Enum
- RIGHT — Enum
- JUSTIFY — Enum
