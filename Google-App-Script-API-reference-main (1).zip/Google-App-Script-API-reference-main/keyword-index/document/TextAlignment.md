## TextAlignment

### Properties

- NORMAL — Enum
- SUPERSCRIPT — Enum
- SUBSCRIPT — Enum
