## PositionedLayout

### Properties

- ABOVE_TEXT — Enum
- BREAK_BOTH — Enum
- BREAK_LEFT — Enum
- BREAK_RIGHT — Enum
- WRAP_TEXT — Enum
