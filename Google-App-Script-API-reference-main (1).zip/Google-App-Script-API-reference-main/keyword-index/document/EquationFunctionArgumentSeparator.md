## EquationFunctionArgumentSeparator

### Methods

- copy() — EquationFunctionArgumentSeparator
- getAttributes() — Object
- getNextSibling() — Element
- getParent() — ContainerElement
- getPreviousSibling() — Element
- getType() — ElementType
- isAtDocumentEnd() — Boolean
- merge() — EquationFunctionArgumentSeparator
- removeFromParent() — EquationFunctionArgumentSeparator
- setAttributes(attributes) — EquationFunctionArgumentSeparator
