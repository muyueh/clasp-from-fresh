## Tab

### Methods

- asDocumentTab() — DocumentTab
- getChildTabs() — Tab[]
- getId() — String
- getIndex() — Integer
- getTitle() — String
- getType() — TabType
