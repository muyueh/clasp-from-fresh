## GmailLabel

### Methods

- addToThread(thread) — GmailLabel
- addToThreads(threads) — GmailLabel
- deleteLabel() — void
- getId() — String
- getName() — String
- getThreads() — GmailThread[]
- getThreads(start, max) — GmailThread[]
- getUnreadCount() — Integer
- removeFromThread(thread) — GmailLabel
- removeFromThreads(threads) — GmailLabel
