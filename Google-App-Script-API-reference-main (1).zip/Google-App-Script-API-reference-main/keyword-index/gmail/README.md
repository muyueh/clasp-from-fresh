# Gmail Service

## Classes

- GmailApp — Provides access to Gmail threads, messages, and labels.
- GmailAttachment — An attachment from Gmail.
- GmailDraft — A user-created draft message in a user's Gmail account.
- GmailLabel — A user-created label in a user's Gmail account.
- GmailMessage — A message in a user's Gmail account.
- GmailThread — A thread in a user's Gmail account.
