## GmailAttachment

### Methods

- copyBlob() — Blob
- getAs(contentType) — Blob
- getBytes() — Byte[]
- getContentType() — String
- getDataAsString() — String
- getDataAsString(charset) — String
- getHash() — String
- getName() — String
- getSize() — Integer
- isGoogleType() — Boolean
- setBytes(data) — Blob
- setContentType(contentType) — Blob
- setContentTypeFromExtension() — Blob
- setDataFromString(string) — Blob
- setDataFromString(string, charset) — Blob
- setName(name) — Blob
