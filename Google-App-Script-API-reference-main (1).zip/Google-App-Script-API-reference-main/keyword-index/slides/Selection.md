## Selection

### Methods

- getCurrentPage() — Page
- getPageElementRange() — PageElementRange
- getPageRange() — PageRange
- getSelectionType() — SelectionType
- getTableCellRange() — TableCellRange
- getTextRange() — TextRange
