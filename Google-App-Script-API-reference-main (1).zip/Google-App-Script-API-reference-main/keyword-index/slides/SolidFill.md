## SolidFill

### Methods

- getAlpha() — Number
- getColor() — Color
