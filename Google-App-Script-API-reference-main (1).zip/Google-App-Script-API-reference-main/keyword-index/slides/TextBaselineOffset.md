## TextBaselineOffset

### Properties

- UNSUPPORTED — Enum
- NONE — Enum
- SUPERSCRIPT — Enum
- SUBSCRIPT — Enum
