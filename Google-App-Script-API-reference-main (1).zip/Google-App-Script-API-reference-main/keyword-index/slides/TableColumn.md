## TableColumn

### Methods

- getCell(cellIndex) — TableCell
- getIndex() — Integer
- getNumCells() — Integer
- getParentTable() — Table
- getWidth() — Number
- remove() — void
