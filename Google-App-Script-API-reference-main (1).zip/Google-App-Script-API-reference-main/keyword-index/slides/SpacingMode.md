## SpacingMode

### Properties

- UNSUPPORTED — Enum
- NEVER_COLLAPSE — Enum
- COLLAPSE_LISTS — Enum
