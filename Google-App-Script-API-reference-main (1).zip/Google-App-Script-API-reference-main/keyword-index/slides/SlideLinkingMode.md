## SlideLinkingMode

### Properties

- UNSUPPORTED — Enum
- LINKED — Enum
- NOT_LINKED — Enum
