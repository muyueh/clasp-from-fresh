## TableCell

### Methods

- getColumnIndex() — Integer
- getColumnSpan() — Integer
- getContentAlignment() — ContentAlignment
- getFill() — Fill
- getHeadCell() — TableCell
- getMergeState() — CellMergeState
- getParentColumn() — TableColumn
- getParentRow() — TableRow
- getParentTable() — Table
- getRowIndex() — Integer
- getRowSpan() — Integer
- getText() — TextRange
- setContentAlignment(contentAlignment) — TableCell
