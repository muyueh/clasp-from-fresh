## LineCategory

### Properties

- UNSUPPORTED — Enum
- STRAIGHT — Enum
- BENT — Enum
- CURVED — Enum
