## TableCellRange

### Methods

- getTableCells() — TableCell[]
