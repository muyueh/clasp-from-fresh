## PageType

### Properties

- UNSUPPORTED — Enum
- SLIDE — Enum
- LAYOUT — Enum
- MASTER — Enum
