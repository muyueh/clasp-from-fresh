## LinkType

### Properties

- UNSUPPORTED — Enum
- URL — Enum
- SLIDE_POSITION — Enum
- SLIDE_ID — Enum
- SLIDE_INDEX — Enum
