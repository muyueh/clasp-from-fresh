## TextDirection

### Properties

- UNSUPPORTED — Enum
- LEFT_TO_RIGHT — Enum
- RIGHT_TO_LEFT — Enum
