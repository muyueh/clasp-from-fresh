## SlidePosition

### Properties

- NEXT_SLIDE — Enum
- PREVIOUS_SLIDE — Enum
- FIRST_SLIDE — Enum
- LAST_SLIDE — Enum
