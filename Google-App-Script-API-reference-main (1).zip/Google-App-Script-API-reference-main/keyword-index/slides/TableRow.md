## TableRow

### Methods

- getCell(cellIndex) — TableCell
- getIndex() — Integer
- getMinimumHeight() — Number
- getNumCells() — Integer
- getParentTable() — Table
- remove() — void
