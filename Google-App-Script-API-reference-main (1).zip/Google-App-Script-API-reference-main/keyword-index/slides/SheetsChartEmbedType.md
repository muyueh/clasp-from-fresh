## SheetsChartEmbedType

### Properties

- UNSUPPORTED — Enum
- IMAGE — Enum
