## Point

### Methods

- getX() — Number
- getY() — Number
