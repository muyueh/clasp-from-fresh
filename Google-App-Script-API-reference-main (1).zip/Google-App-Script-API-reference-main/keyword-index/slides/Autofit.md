## Autofit

### Methods

- disableAutofit() — Autofit
- getAutofitType() — AutofitType
- getFontScale() — Number
- getLineSpacingReduction() — Number
