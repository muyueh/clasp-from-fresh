## Link

### Methods

- getLinkType() — LinkType
- getLinkedSlide() — Slide
- getSlideId() — String
- getSlideIndex() — Integer
- getSlidePosition() — SlidePosition
- getUrl() — String
