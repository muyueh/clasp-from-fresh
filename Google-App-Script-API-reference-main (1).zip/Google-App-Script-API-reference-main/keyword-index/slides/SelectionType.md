## SelectionType

### Properties

- UNSUPPORTED — Enum
- NONE — Enum
- TEXT — Enum
- TABLE_CELL — Enum
- PAGE — Enum
- PAGE_ELEMENT — Enum
- CURRENT_PAGE — Enum
