## PredefinedLayout

### Properties

- UNSUPPORTED — Enum
- BLANK — Enum
- CAPTION_ONLY — Enum
- TITLE — Enum
- TITLE_AND_BODY — Enum
- TITLE_AND_TWO_COLUMNS — Enum
- TITLE_ONLY — Enum
- SECTION_HEADER — Enum
- SECTION_TITLE_AND_DESCRIPTION — Enum
- ONE_COLUMN_TEXT — Enum
- MAIN_POINT — Enum
- BIG_NUMBER — Enum
