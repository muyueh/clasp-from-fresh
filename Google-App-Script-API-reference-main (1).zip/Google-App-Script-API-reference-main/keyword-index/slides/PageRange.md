## PageRange

### Methods

- getPages() — Page[]
