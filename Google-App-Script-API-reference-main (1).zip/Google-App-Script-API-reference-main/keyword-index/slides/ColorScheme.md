## ColorScheme

### Methods

- getConcreteColor(theme) — Color
- getThemeColors() — ThemeColorType[]
- setConcreteColor(type, color) — ColorScheme
- setConcreteColor(type, red, green, blue) — ColorScheme
- setConcreteColor(type, hexColor) — ColorScheme
