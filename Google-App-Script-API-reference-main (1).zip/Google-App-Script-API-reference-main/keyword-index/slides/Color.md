## Color

### Methods

- asRgbColor() — RgbColor
- asThemeColor() — ThemeColor
- getColorType() — ColorType
