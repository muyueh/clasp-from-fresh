## PlaceholderType

### Properties

- UNSUPPORTED — Enum
- NONE — Enum
- BODY — Enum
- CHART — Enum
- CLIP_ART — Enum
- CENTERED_TITLE — Enum
- DIAGRAM — Enum
- DATE_AND_TIME — Enum
- FOOTER — Enum
- HEADER — Enum
- MEDIA — Enum
- OBJECT — Enum
- PICTURE — Enum
- SLIDE_NUMBER — Enum
- SUBTITLE — Enum
- TABLE — Enum
- TITLE — Enum
- SLIDE_IMAGE — Enum
