## Paragraph

### Methods

- getIndex() — Integer
- getRange() — TextRange
