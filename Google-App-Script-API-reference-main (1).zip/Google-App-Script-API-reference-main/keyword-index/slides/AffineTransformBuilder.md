## AffineTransformBuilder

### Methods

- build() — AffineTransform
- setScaleX(scaleX) — AffineTransformBuilder
- setScaleY(scaleY) — AffineTransformBuilder
- setShearX(shearX) — AffineTransformBuilder
- setShearY(shearY) — AffineTransformBuilder
- setTranslateX(translateX) — AffineTransformBuilder
- setTranslateY(translateY) — AffineTransformBuilder
